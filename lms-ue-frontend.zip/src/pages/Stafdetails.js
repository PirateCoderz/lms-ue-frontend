import React from 'react'

const Stafdetails = () => (
    <div>Stafdetails</div>
  )

export default Stafdetails