/* eslint-disable import/no-unresolved */
import { Typography } from '@mui/material'
import React from 'react'
import GoogleMap from 'src/Comp/GoogleMap'

const MeritListPage = () => (
  //  <GoogleMap/>
  <Typography>dknf</Typography>
  )

export default MeritListPage