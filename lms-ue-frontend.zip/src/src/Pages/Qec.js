import React from 'react'

const Qec = () => {
  return (
    <div>Qec</div>
  )
}

export default Qec