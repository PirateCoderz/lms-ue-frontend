import React from 'react'

const LatestNews = () => {
  return (
    <div>LatestNews</div>
  )
}

export default LatestNews