import React from 'react'

const Acadmic = () => {
  return (
    <div>Acadmic</div>
  )
}

export default Acadmic