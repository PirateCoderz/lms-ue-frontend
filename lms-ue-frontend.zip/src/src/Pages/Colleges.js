import React from 'react'

const Colleges = () => {
  return (
    <div>Colleges</div>
  )
}

export default Colleges