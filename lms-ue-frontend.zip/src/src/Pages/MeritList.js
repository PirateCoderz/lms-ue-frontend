/* eslint-disable arrow-body-style */
import React from 'react'
import MeritLists from "../components/MeritList"

const MeritList = () => {
  return (
    <div><MeritLists/></div>
  )
}

export default MeritList