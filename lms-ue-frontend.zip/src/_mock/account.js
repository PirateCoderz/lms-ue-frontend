// ----------------------------------------------------------------------

const account = {
  displayName: 'Ateeq Shareef',
  email: 'ateeqshareef11@gmail.com',
  photoURL: 'https://pbs.twimg.com/profile_images/1448462151056822273/fRng_Gmy_400x400.jpg',
};

export default account;
